package ejerciciosUD3;

public class Notas {
public static void main(String args[]) {
	int notas[] = new int[] {8,10,2,5,7};
	
	//Bucle y mostrar por pantalla las notas
	for(int i=0;i<=5;i++) {
		System.out.print(notas[i]+" ");
	}
}
}
